const { MessageActionRow, MessageButton, MessageEmbed, Permissions} = require('discord.js');
const fs = require('fs');
const sleep = require('sleep-promise');

module.exports = {
    name: "setback",
    description: "Settings Back",
    async execute(client, interaction) {
        fs.readFile(`Server/${interaction.message.member.guild.id.toString()}.json`, "utf8", async function (err,data) {
            if (err) {
                console.log(err);
            }

            var json_data = JSON.parse(data);
            var adminroles = json_data.moderation.roles_admin;
            var modroles = json_data.moderation.roles_mod;
            var modberecht = false;
            var adminberecht = false;


            for (var i of interaction.message.member._roles) {
                if (interaction.message.guild.ownerId.toString() === interaction.message.member.id.toString()) {
                    adminberecht = true;
                    modberecht = true;
                    break;
                }
                if (interaction.message.member.permissions.has(Permissions.FLAGS.ADMINISTRATOR)) {
                    adminberecht = true;
                    modberecht = true;
                    break;
                }
                if (adminroles.includes(i.toString())) {
                    adminberecht = true;
                    break;
                }
                if (modroles.includes(i.toString())) {
                    modberecht = true;
                    break;
                }
            }

            if (modberecht === false || adminberecht === false) {
                return client.commands.get("permission_error").execute(client, message);
            }



            if (interaction.customId === "setBack") {
                client.commands.get("set").execute(client, interaction.message);
                await sleep(500);
                await interaction.message.delete();
            }
            if (interaction.customId === "setManageBack") {
                client.sets.get("setbuttonmanage").execute(client, interaction);
            }
            if (interaction.customId === "setManageAMBack") {
                client.sets.get("setbuttonmanageam").execute(client, interaction);
            }
            if (interaction.customId === "setManageAMICBack") {
                client.sets.get("setbuttonmanageamic").execute(client, interaction);
            }
            if (interaction.customId === "setManageAMIRBack") {
                client.sets.get("setbuttonmanageamir").execute(client, interaction);
            }
            if (interaction.customId === "setManageAMFWBack") {
                client.sets.get("setbuttonmanageamfw").execute(client, interaction);
            }
            if (interaction.customId === "setManageAMFLBack") {
                client.sets.get("setbuttonmanageamfl").execute(client, interaction);
            }
        });
    }
}